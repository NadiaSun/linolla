new S3SolutionsPanel({
	themes: [
		['#55616f', '#ff6b6b', '#dde0e2', '#ffffff'],
		['#eedaa6', '#ff6b6b', '#fcf8ed', '#ffffff'],
		['#006f6a', '#edd874', '#cce2e1', '#ffffff'],
		['#6b4337', '#e8a166', '#e1d9d7', '#ffffff'],
		['#c22d2d', '#c0dc66', '#f3d5d5', '#ffffff'],
		['#333333', '#8c8c8c', '#d6d6d6', '#ffffff'],
		['#628767', '#2e3438', '#e0e7e1', '#ffffff'],
		['#006c80', '#ebcab8', '#cce2e6', '#ffffff'],
		['#997533', '#190e02', '#ebe3d6', '#ffffff'],
		['#190e02', '#997533', '#d1cfcc', '#ffffff'],
		['#9c4145', '#ff8c58', '#ebd9da', '#ffffff'],
		['#6d3995', '#88a7d3', '#e2d7ea', '#ffffff'],
		['#364245', '#e0dda2', '#d7d9da', '#ffffff'],
		['#c46371', '#2baaad', '#f3e0e3', '#ffffff']
	]
});